// Malzama.Krd Application Engine
document.addEventListener('DOMContentLoaded', () => {
  // Global Application State
  const state = {
    currentGrade: 9,
    currentSubject: 'all', // 'all', 'literature', 'grammar'
    searchQuery: '',
    sortBy: 'newest', // 'newest', 'price-low', 'price-high'
    cart: [
      { id: 'b9-1', title: 'کوردی پۆلی کتێبی قوتابی', price: 24000, qty: 1, img: 'assets/images/book_kurdish_9_student_1790446968708.png' },
      { id: 'b9-4', title: 'زمان و ئەدەب بۆ پۆلی 9', price: 22000, qty: 1, img: 'assets/images/book_kurdish_9_literature_1790447021955.png' }
    ],
    usedBooks: [
      {
        id: 'u1',
        title: 'کتێبی بیریاری پۆلی 12 (دەستی دوو)',
        grade: 'پۆلی 12',
        condition: 'زۆر باش (نوێ)',
        price: 12000,
        seller: 'ئاراس ئەحمەد',
        phone: '07501234567',
        img: 'assets/images/book_kurdish_9_purple_1790447004624.png'
      },
      {
        id: 'u2',
        title: 'کیمیای پۆلی 11 زانستی',
        grade: 'پۆلی 11',
        condition: 'پاک و بێ خەت',
        price: 9000,
        seller: 'سارا عومەر',
        phone: '07709876543',
        img: 'assets/images/book_kurdish_9_grammar_1790447037156.png'
      }
    ],
    orders: [
      {
        id: 'MZ-8842',
        date: '2026-09-25',
        total: 46000,
        status: 'لە پرۆسەکردندا',
        step: 2, // 1: Received, 2: Processing, 3: On standard delivery, 4: Delivered
        items: 'کوردی پۆلی کتێبی قوتابی x1, زمان و ئەدەب x1'
      }
    ],
    notifications: [
      { id: 1, title: 'داواکاریەکەت وەرگیرا', desc: 'داواکاری #MZ-8842 لە پرۆسەی ئامادەکردندایە.', time: 'پێش ٢ کژمێر' },
      { id: 2, title: 'داشکاندنی تایبەت!', desc: 'کتێبەکانی پۆلی ١٢ تا %٢٠ داشکاندنیان بۆ کراوە.', time: 'دوێنێ' }
    ],
    currentView: 'sereki' // 'sereki', 'dasti2', 'kart', 'orders', 'profile'
  };

  // Books Master Database
  const booksData = [
    // Grade 9
    {
      id: 'b9-1',
      title: 'کوردی پۆلی کتێبی قوتابی',
      subtitle: 'کوردی پۆلی 9',
      price: 24000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_student_1790446968708.png',
      desc: 'کتێبی سەرەکی خوێندنی کوردی بۆ پۆلی نۆیەمی بنەڕەتی بەپێی نوێترین بەرنامەی وەزارەتی پەروەردە.'
    },
    {
      id: 'b9-2',
      title: 'کوردی پۆلی کتێبی وەرزشی',
      subtitle: 'کوردی پۆلی 9',
      price: 18000,
      grade: 9,
      subject: 'all',
      img: 'assets/images/book_kurdish_9_tree_1790446985742.png',
      desc: 'ڕێنمایی و بەرنامەی چالاکییە وەرزشییەکان بۆ پەروەردەی جەستەیی پۆلی نۆیەم.'
    },
    {
      id: 'b9-3',
      title: 'کوردی بۆ کتێبی مامۆستا',
      subtitle: 'کوردی پۆلی 9',
      price: 20000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_purple_1790447004624.png',
      desc: 'کتێبی ڕێنمایی مامۆستا بۆ وانەوتنەوە و ڕوونکردنەوەی ناورۆکی کتێبی کوردی پۆلی 9.'
    },
    {
      id: 'b9-4',
      title: 'زمان و ئەدەب بۆ پۆلی 9',
      subtitle: 'زمان و ئەدەب پۆلی 9',
      price: 22000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_literature_1790447021955.png',
      desc: 'شیکاری دەقە ئەدەبییەکان و هۆنراوەکانی پۆلی نۆیەم بە مێژووی ئەدەبەوە.'
    },
    {
      id: 'b9-5',
      title: 'ڕێزمان پۆلی 9',
      subtitle: 'ڕێزمان پۆلی 9',
      price: 21000,
      grade: 9,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_grammar_1790447037156.png',
      desc: 'یاساکانی ڕێزمانی کوردی و دارشتن و وشەسازی بۆ ئەزموونەکانی پۆلی نۆیەم.'
    },
    {
      id: 'b9-6',
      title: 'دەقی کوردی پۆلی 9',
      subtitle: 'دەقی کوردی پۆلی 9',
      price: 19000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_student_1790446968708.png',
      desc: 'کۆمەڵە دەق و پەخشانی ئەدەبی هەڵبژێردراو بۆ بەرەوپێشبردنی زمانی کوردی.'
    },

    // Grade 10
    {
      id: 'b10-1',
      title: 'کوردی پۆلی 10 (کۆمەڵایەتی)',
      subtitle: 'پۆلی 10',
      price: 25000,
      grade: 10,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_tree_1790446985742.png',
      desc: 'کتێبی ڕێزمانی کوردی و ئەدەب بۆ پۆلی دەیەمی ئامادەیی.'
    },
    {
      id: 'b10-2',
      title: 'ڕێزمانی پێشکەوتووی پۆلی 10',
      subtitle: 'پۆلی 10',
      price: 23000,
      grade: 10,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_grammar_1790447037156.png',
      desc: 'شیکردنەوەی قووڵی ڕێزمانی کوردی بۆ قوتابیانی پۆلی دەیەم.'
    },

    // Grade 11
    {
      id: 'b11-1',
      title: 'کوردی پۆلی 11 (زانستی و وێژەیی)',
      subtitle: 'پۆلی 11',
      price: 26000,
      grade: 11,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_purple_1790447004624.png',
      desc: 'پڕۆگرامی وانەی کوردی پۆلی یازدەیەم بە بابەتە ئەدەبی و زانستییەکانەوە.'
    },

    // Grade 12
    {
      id: 'b12-1',
      title: 'مەلزەمەی ئەدەب و ڕێزمانی پۆلی 12',
      subtitle: 'پۆلی 12 - ئەلند',
      price: 28000,
      grade: 12,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_literature_1790447021955.png',
      desc: 'مەلزەمەی گشتگیر و کورتکراوەی پۆلی 12 بۆ ئەزموونە گشتییەکان (بەکالۆریۆس).'
    },
    {
      id: 'b12-2',
      title: 'کتێبی ڕێزمانی وزاری پۆلی 12',
      subtitle: 'پۆلی 12',
      price: 27000,
      grade: 12,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_student_1790446968708.png',
      desc: 'پرسیارەکانی وەزاری خولەکانی پێشوو بە وەڵامی داڕێژراوەوە.'
    }
  ];

  // UI Elements
  const booksGrid = document.getElementById('booksGrid');
  const sectionTitle = document.getElementById('sectionTitle');
  const cartBadge = document.getElementById('cartBadge');
  const cartNavBadge = document.getElementById('cartNavBadge');
  const searchInput = document.getElementById('searchInput');
  const searchClear = document.getElementById('searchClear');
  const toastContainer = document.getElementById('toastContainer');
  const modalOverlay = document.getElementById('modalOverlay');
  const modalBody = document.getElementById('modalBody');

  // Render Functions
  function renderBooks() {
    let filtered = booksData.filter(b => b.grade === state.currentGrade);

    // Subject Filter
    if (state.currentSubject !== 'all') {
      filtered = filtered.filter(b => b.subject === state.currentSubject);
    }

    // Search Filter
    if (state.searchQuery.trim() !== '') {
      const q = state.searchQuery.toLowerCase();
      filtered = booksData.filter(b => 
        b.title.toLowerCase().includes(q) || 
        b.subtitle.toLowerCase().includes(q) || 
        b.desc.toLowerCase().includes(q)
      );
    }

    // Sort Filter
    if (state.sortBy === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (state.sortBy === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    }

    // Update section title text
    if (state.searchQuery.trim() !== '') {
      sectionTitle.textContent = `ئەنجامەکانی گەڕان (${filtered.length})`;
    } else {
      sectionTitle.textContent = `کتێبەکانی پۆلی ${state.currentGrade} - کوردی`;
    }

    if (filtered.length === 0) {
      booksGrid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon"><i class="fa-solid fa-book-open"></i></div>
          <div class="empty-title">هیچ کتێبێک نەدۆزرایەوە</div>
          <div class="empty-desc">تکایە وشەی تر تاقی بکەرەوە یان پۆلەکە بگۆڕە.</div>
        </div>
      `;
      return;
    }

    booksGrid.innerHTML = filtered.map(book => `
      <div class="book-card" data-id="${book.id}">
        <div class="book-cover-wrapper">
          <img src="${book.img}" alt="${book.title}" class="book-cover-img">
          <div class="book-spine-effect"></div>
          <span class="book-badge">پۆلی ${book.grade}</span>
        </div>
        <div class="book-info">
          <div>
            <div class="book-title">${book.title}</div>
            <div class="book-subtitle">${book.subtitle}</div>
          </div>
          <div>
            <div class="book-price">${book.price.toLocaleString()} IQD</div>
            <button class="add-cart-btn" data-id="${book.id}">
              <i class="fa-solid fa-cart-shopping"></i>
            </button>
          </div>
        </div>
      </div>
    `).join('');

    // Attach card click handlers
    document.querySelectorAll('.book-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.add-cart-btn')) return; // handled separately
        const id = card.getAttribute('data-id');
        showBookDetails(id);
      });
    });

    // Attach cart button handlers
    document.querySelectorAll('.add-cart-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        addToCart(id);
      });
    });
  }

  function updateCartBadge() {
    const totalQty = state.cart.reduce((sum, item) => sum + item.qty, 0);
    cartBadge.textContent = totalQty;
    cartNavBadge.textContent = totalQty;
    if (totalQty === 0) {
      cartBadge.style.display = 'none';
      cartNavBadge.style.display = 'none';
    } else {
      cartBadge.style.display = 'flex';
      cartNavBadge.style.display = 'flex';
    }
  }

  function addToCart(bookId) {
    const book = booksData.find(b => b.id === bookId);
    if (!book) return;

    const existing = state.cart.find(item => item.id === bookId);
    if (existing) {
      existing.qty += 1;
    } else {
      state.cart.push({
        id: book.id,
        title: book.title,
        price: book.price,
        qty: 1,
        img: book.img
      });
    }

    updateCartBadge();
    showToast(`"${book.title}" زێدە کرایە سەبەتەکەت`);
    if (state.currentView === 'kart') renderCartView();
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${message}`;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  // Views Switching Logic
  function switchView(viewName) {
    state.currentView = viewName;

    // Update nav icons active state
    document.querySelectorAll('.nav-item').forEach(item => {
      if (item.getAttribute('data-view') === viewName) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Toggle pages visibility
    document.querySelectorAll('.page-view').forEach(view => {
      if (view.id === `view-${viewName}`) {
        view.classList.add('active');
      } else {
        view.classList.remove('active');
      }
    });

    if (viewName === 'kart') renderCartView();
    if (viewName === 'dasti2') renderUsedBooksView();
    if (viewName === 'orders') renderOrdersView();
    if (viewName === 'profile') renderProfileView();

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Render Views Content
  function renderCartView() {
    const cartContainer = document.getElementById('cartContent');
    if (state.cart.length === 0) {
      cartContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon"><i class="fa-solid fa-cart-flatbed"></i></div>
          <div class="empty-title">سەبەتەکەت بەتاڵە</div>
          <div class="empty-desc">هیچ کتێبێکت زیاده نەکردووە بۆ کڕین.</div>
          <button class="checkout-btn" style="max-width:200px; margin:20px auto 0;" id="btnGoHome">دەستپێکردنی کڕین</button>
        </div>
      `;
      document.getElementById('btnGoHome')?.addEventListener('click', () => switchView('sereki'));
      return;
    }

    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const delivery = 3000;
    const total = subtotal + delivery;

    cartContainer.innerHTML = `
      <div class="cart-items-list">
        ${state.cart.map(item => `
          <div class="cart-item-card">
            <img src="${item.img}" alt="${item.title}" class="cart-item-img">
            <div class="cart-item-info">
              <div class="cart-item-title">${item.title}</div>
              <div class="cart-item-price">${(item.price * item.qty).toLocaleString()} IQD</div>
            </div>
            <div class="qty-controls">
              <button class="qty-btn" onclick="window.changeCartQty('${item.id}', 1)">+</button>
              <span style="font-size:0.9rem; font-weight:700;">${item.qty}</span>
              <button class="qty-btn" onclick="window.changeCartQty('${item.id}', -1)">-</button>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="cart-summary">
        <div class="summary-row">
          <span>تێکڕای بەا:</span>
          <span>${subtotal.toLocaleString()} IQD</span>
        </div>
        <div class="summary-row">
          <span>کرێی گەیاندن:</span>
          <span>${delivery.toLocaleString()} IQD</span>
        </div>
        <div class="summary-row total">
          <span>کۆی گشتی:</span>
          <span style="color:var(--primary);">${total.toLocaleString()} IQD</span>
        </div>
        <button class="checkout-btn" id="btnCheckout">بەردەوامبوون بۆ پارەدان</button>
      </div>
    `;

    document.getElementById('btnCheckout').addEventListener('click', openCheckoutModal);
  }

  window.changeCartQty = function(id, delta) {
    const item = state.cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) {
      state.cart = state.cart.filter(i => i.id !== id);
    }
    updateCartBadge();
    renderCartView();
  };

  function renderUsedBooksView() {
    const container = document.getElementById('usedBooksContent');
    container.innerHTML = `
      <div class="used-hero">
        <div>
          <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:4px;">بازاڕی کتێبی دەستی دوو</h3>
          <p style="font-size:0.85rem; opacity:0.9;">کتێبە کۆنەکانت بەبێ بەرامبەر بفرۆشە یان بپشکنە!</p>
        </div>
        <button class="btn-add-used" id="btnAddUsedBook">+ زیاده‌کردنی کتێب</button>
      </div>

      <div class="used-grid">
        ${state.usedBooks.map(item => `
          <div class="used-card">
            <img src="${item.img}" class="used-img" alt="${item.title}">
            <div class="used-details">
              <div>
                <span class="used-tag">${item.condition}</span>
                <h4 style="font-size:0.95rem; font-weight:800; margin:6px 0 2px;">${item.title}</h4>
                <p style="font-size:0.8rem; color:var(--text-muted);">${item.grade} • خاوەن: ${item.seller}</p>
              </div>
              <div style="display:flex; align-items:center; justify-content:space-between; margin-top:8px;">
                <span style="font-weight:800; color:#059669; font-size:0.9rem;">${item.price.toLocaleString()} IQD</span>
                <a href="tel:${item.phone}" class="used-contact-btn"><i class="fa-solid fa-phone"></i> پەیوەندی</a>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    document.getElementById('btnAddUsedBook').addEventListener('click', openAddUsedModal);
  }

  function renderOrdersView() {
    const container = document.getElementById('ordersContent');
    if (state.orders.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon"><i class="fa-solid fa-box-open"></i></div>
          <div class="empty-title">هیچ داواکاریەکت نییە</div>
          <div class="empty-desc">کاتێک داواکاری بکەیت لەم بەشەدا دەردەکەوێت.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = state.orders.map(order => `
      <div class="order-card">
        <div class="order-header">
          <span>کۆدی داواکاری: ${order.id}</span>
          <span class="status-badge ${order.step === 4 ? 'delivered' : 'processing'}">${order.status}</span>
        </div>
        <div style="font-size:0.82rem; color:var(--text-muted); margin-bottom:8px;">
          ڕێککەوت: ${order.date} • کۆی گشتی: ${order.total.toLocaleString()} IQD
        </div>
        <div style="font-size:0.85rem; font-weight:600; background:var(--secondary-bg); padding:8px 12px; border-radius:8px; margin-bottom:12px;">
          ${order.items}
        </div>
        
        <div class="order-tracker">
          <div class="tracker-step ${order.step >= 1 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-check"></i></div>
            <span>وەرگیرا</span>
          </div>
          <div class="tracker-step ${order.step >= 2 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-gear"></i></div>
            <span>پرۆسەکردن</span>
          </div>
          <div class="tracker-step ${order.step >= 3 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-truck"></i></div>
            <span>لە ڕێگایە</span>
          </div>
          <div class="tracker-step ${order.step >= 4 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-house"></i></div>
            <span>گەیەندرا</span>
          </div>
        </div>
      </div>
    `).join('');
  }

  function renderProfileView() {
    const container = document.getElementById('profileContent');
    container.innerHTML = `
      <div class="profile-card">
        <div class="avatar-wrapper">
          <img src="https://ui-avatars.com/api/?name=Kurdish+Student&background=0070f3&color=fff&size=128" alt="Profile" class="avatar-img">
        </div>
        <h3 style="font-size:1.2rem; font-weight:800;">خوێندکاری دەستڕەنگین</h3>
        <p style="font-size:0.85rem; color:var(--text-muted);">0750 123 4567 • هەولێر، کوردستان</p>
      </div>

      <div class="profile-menu">
        <div class="menu-item" id="btnToggleTheme">
          <div class="menu-item-left">
            <i class="fa-solid fa-moon"></i>
            <span>دۆخی تاریک (Dark Mode)</span>
          </div>
          <i class="fa-solid fa-chevron-left" style="font-size:12px; color:var(--text-muted);"></i>
        </div>
        <div class="menu-item" onclick="alert('پەیوەندی بە پشتگیری: 0750 000 0000')">
          <div class="menu-item-left">
            <i class="fa-solid fa-headset"></i>
            <span>پشتیوانی و پەیوەندی</span>
          </div>
          <i class="fa-solid fa-chevron-left" style="font-size:12px; color:var(--text-muted);"></i>
        </div>
        <div class="menu-item" onclick="alert('Malzama.Krd v2.5.0 - هەموو مافەکانی پارێزراوە 2026')">
          <div class="menu-item-left">
            <i class="fa-solid fa-circle-info"></i>
            <span>دەربارەی مەلزەمە کورد</span>
          </div>
          <i class="fa-solid fa-chevron-left" style="font-size:12px; color:var(--text-muted);"></i>
        </div>
      </div>
    `;

    document.getElementById('btnToggleTheme').addEventListener('click', () => {
      document.body.classList.toggle('dark-theme');
      showToast('دۆخی ڕووناکی / تاریکی گۆڕدرا');
    });
  }

  // Modals Implementation
  function showBookDetails(bookId) {
    const book = booksData.find(b => b.id === bookId);
    if (!book) return;

    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <div style="text-align:center; margin-bottom:16px;">
        <img src="${book.img}" style="width:140px; height:180px; object-fit:cover; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.15);" alt="${book.title}">
      </div>
      <h3 style="font-size:1.25rem; font-weight:800; text-align:center; margin-bottom:4px;">${book.title}</h3>
      <p style="text-align:center; font-size:0.85rem; color:var(--text-muted); margin-bottom:16px;">${book.subtitle} • بڵاوکراوەی فەرمی</p>
      
      <p style="font-size:0.9rem; line-height:1.6; margin-bottom:20px; color:var(--text-main);">${book.desc}</p>
      
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; background:var(--secondary-bg); padding:12px 16px; border-radius:12px;">
        <span style="font-size:0.9rem; font-weight:700;">نرخ:</span>
        <span style="font-size:1.2rem; font-weight:800; color:var(--primary);">${book.price.toLocaleString()} IQD</span>
      </div>

      <button class="checkout-btn" id="modalAddToCartBtn">
        <i class="fa-solid fa-cart-plus" style="margin-left:8px;"></i> زێدەکردن بۆ سەبەتە
      </button>
    `;

    modalOverlay.classList.add('active');
    document.getElementById('modalAddToCartBtn').addEventListener('click', () => {
      addToCart(book.id);
      window.closeModal();
    });
  }

  function openCheckoutModal() {
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const total = subtotal + 3000;

    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:16px; text-align:center;">تۆمارکردنی داواکاری</h3>
      
      <form id="checkoutForm">
        <div class="form-group">
          <label>ناوی تەواو</label>
          <input type="text" id="custName" placeholder="ناوی سیانیت بنووسە" required>
        </div>
        <div class="form-group">
          <label>ژمارەی مۆبایل</label>
          <input type="tel" id="custPhone" placeholder="0750 XXX XX XX" required>
        </div>
        <div class="form-group">
          <label>شار / ناوچە</label>
          <select id="custCity">
            <option>هەولێر</option>
            <option>سلێمانی</option>
            <option>دهۆک</option>
            <option>هەڵەبجە</option>
            <option>کەرکووک</option>
          </select>
        </div>
        <div class="form-group">
          <label>ناونیشانی ورد</label>
          <input type="text" id="custAddress" placeholder="گەڕەک / کۆڵان / بەرامبەر..." required>
        </div>

        <div style="margin:16px 0; padding:12px; background:var(--secondary-bg); border-radius:12px; font-weight:800; display:flex; justify-content:space-between;">
          <span>کۆی پارەدانی کۆتایی:</span>
          <span style="color:var(--primary);">${total.toLocaleString()} IQD</span>
        </div>

        <button type="submit" class="checkout-btn">ناردنی داواکاری</button>
      </form>
    `;

    modalOverlay.classList.add('active');

    document.getElementById('checkoutForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const newOrder = {
        id: `MZ-${Math.floor(1000 + Math.random() * 9000)}`,
        date: new Date().toISOString().split('T')[0],
        total: total,
        status: 'لە پرۆسەکردندا',
        step: 1,
        items: state.cart.map(i => `${i.title} x${i.qty}`).join(', ')
      };

      state.orders.unshift(newOrder);
      state.cart = [];
      updateCartBadge();
      window.closeModal();
      showToast('داواکاریەکەت بە سەرکەوتوویی تۆمارکرا!');
      switchView('orders');
    });
  }

  function openAddUsedModal() {
    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:16px; text-align:center;">زیادکردنی کتێبی دەستی دوو</h3>
      
      <form id="usedBookForm">
        <div class="form-group">
          <label>ناوی کتێب</label>
          <input type="text" id="ubTitle" placeholder="نموونە: بیریاری پۆلی 12" required>
        </div>
        <div class="form-group">
          <label>پۆل</label>
          <select id="ubGrade">
            <option>پۆلی 9</option>
            <option>پۆلی 10</option>
            <option>پۆلی 11</option>
            <option>پۆلی 12</option>
          </select>
        </div>
        <div class="form-group">
          <label>دۆخی کتێب</label>
          <input type="text" id="ubCondition" placeholder="نموونە: پاك و بێ خەت" required>
        </div>
        <div class="form-group">
          <label>نرخ (IQD)</label>
          <input type="number" id="ubPrice" placeholder="10000" required>
        </div>
        <div class="form-group">
          <label>ژمارەی پەیوەندی</label>
          <input type="tel" id="ubPhone" placeholder="0750 XXX XX XX" required>
        </div>

        <button type="submit" class="checkout-btn" style="background:linear-gradient(135deg, #059669 0%, #10b981 100%);">تۆمارکردن لە بازاڕ</button>
      </form>
    `;

    modalOverlay.classList.add('active');

    document.getElementById('usedBookForm').addEventListener('submit', (e) => {
      e.preventDefault();
      state.usedBooks.unshift({
        id: `u${Date.now()}`,
        title: document.getElementById('ubTitle').value,
        grade: document.getElementById('ubGrade').value,
        condition: document.getElementById('ubCondition').value,
        price: parseInt(document.getElementById('ubPrice').value),
        seller: 'خوێندکار',
        phone: document.getElementById('ubPhone').value,
        img: 'assets/images/book_kurdish_9_student_1790446968708.png'
      });

      window.closeModal();
      showToast('کتێبەکەت ڕەوانەی بازاڕی دەستی دوو کرا');
      renderUsedBooksView();
    });
  }

  function showNotificationsModal() {
    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:16px; text-align:center;">ئاگادارییەکان</h3>
      
      <div style="display:flex; flex-direction:column; gap:10px;">
        ${state.notifications.map(n => `
          <div style="padding:12px; background:var(--secondary-bg); border-radius:12px; border-right:4px solid var(--primary);">
            <div style="font-weight:700; font-size:0.92rem; margin-bottom:2px;">${n.title}</div>
            <div style="font-size:0.82rem; color:var(--text-muted); margin-bottom:4px;">${n.desc}</div>
            <div style="font-size:0.75rem; color:var(--text-light);">${n.time}</div>
          </div>
        `).join('')}
      </div>
    `;
    modalOverlay.classList.add('active');
  }

  window.closeModal = function() {
    modalOverlay.classList.remove('active');
  };

  // Setup Event Listeners
  function setupEventListeners() {
    // Grade Filter Pills
    document.querySelectorAll('.grade-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.grade-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        state.currentGrade = parseInt(tab.getAttribute('data-grade'));
        state.searchQuery = '';
        searchInput.value = '';
        renderBooks();
      });
    });

    // Sub Filter Tabs
    document.querySelectorAll('.sub-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.sub-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        state.currentSubject = tab.getAttribute('data-sub');
        renderBooks();
      });
    });

    // Search Input
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value;
      renderBooks();
    });

    searchClear.addEventListener('click', () => {
      searchInput.value = '';
      state.searchQuery = '';
      renderBooks();
    });

    // Navigation Items
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => {
        const view = item.getAttribute('data-view');
        switchView(view);
      });
    });

    // Header Cart & Notifications
    document.getElementById('headerCartBtn').addEventListener('click', () => switchView('kart'));
    document.getElementById('headerNotifBtn').addEventListener('click', showNotificationsModal);

    // Modal Background Overlay Click
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) window.closeModal();
    });
  }

  // Initialize App
  function init() {
    setupEventListeners();
    updateCartBadge();
    renderBooks();
  }

  init();
});
